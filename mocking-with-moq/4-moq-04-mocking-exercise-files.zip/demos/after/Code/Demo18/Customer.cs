namespace PluralSight.Moq.Code.Demo18
{
    public class Customer
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}