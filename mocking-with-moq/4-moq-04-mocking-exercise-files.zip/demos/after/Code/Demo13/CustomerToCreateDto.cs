namespace PluralSight.Moq.Code.Demo13
{
    public class CustomerToCreateDto
    {
        public string Name { get; set; }
    }
}