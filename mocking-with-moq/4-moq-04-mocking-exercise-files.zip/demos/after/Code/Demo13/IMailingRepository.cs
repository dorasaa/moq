namespace PluralSight.Moq.Code.Demo13
{
    public interface IMailingRepository
    {
        void NewCustomerMessage(string name);
    }
}