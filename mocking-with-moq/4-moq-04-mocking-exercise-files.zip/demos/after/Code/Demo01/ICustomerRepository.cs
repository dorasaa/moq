namespace PluralSight.Moq.Code.Demo01
{
    public interface ICustomerRepository
    {
        void Save(Customer customer);
    }
}