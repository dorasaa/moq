namespace PluralSight.Moq.Code.Demo16
{
    public interface ICustomerRepository
    {
        void Save(Customer customer);
    }
}