namespace PluralSight.Moq.Code.Demo16
{
    public class CustomerToCreateDto
    {
        public string Name { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string PostalZipCode { get; set; }
    }
}