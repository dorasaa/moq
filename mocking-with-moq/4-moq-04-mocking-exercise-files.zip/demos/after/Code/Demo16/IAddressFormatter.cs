namespace PluralSight.Moq.Code.Demo16
{
    public interface IAddressFormatter
    {
        Address From(CustomerToCreateDto customerToCreate);
    }
}