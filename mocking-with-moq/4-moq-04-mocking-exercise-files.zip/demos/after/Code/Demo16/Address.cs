namespace PluralSight.Moq.Code.Demo16
{
    public class Address
    {
    }
}