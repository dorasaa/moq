using System;

namespace PluralSight.Moq.Code.Demo10
{
    public class InvalidWorkstationIdException : Exception
    {
    }
}