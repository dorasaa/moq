namespace PluralSight.Moq.Code.Demo10
{
    public interface IApplicationSettings
    {
        int? WorkstationId { get; set; }
    }
}