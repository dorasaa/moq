namespace PluralSight.Moq.Code.Demo10
{
    public class Customer
    {
        public string Name { get; set; }

        public int WorkstationCreatedOn { get; set; }

        public Customer(string name)
        {
            Name = name;
        }
    }
}