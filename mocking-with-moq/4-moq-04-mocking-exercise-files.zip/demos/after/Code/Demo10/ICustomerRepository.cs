namespace PluralSight.Moq.Code.Demo10
{
    public interface ICustomerRepository
    {
        void Save(Customer customer);
    }
}