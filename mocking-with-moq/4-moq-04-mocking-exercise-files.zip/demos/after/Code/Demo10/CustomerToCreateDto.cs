namespace PluralSight.Moq.Code.Demo10
{
    public class CustomerToCreateDto
    {
        public string Name { get; set; }
    }
}