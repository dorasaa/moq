namespace PluralSight.Moq.Code.Demo08
{
    public interface ICustomerRepository
    {
        void Save(Customer customer);
    }
}