using System;

namespace PluralSight.Moq.Code.Demo08
{
    public class InvalidCustomerAddressException : Exception
    {
    }
}