namespace PluralSight.Moq.Code.Demo08
{
    public class Address
    {
    }
}