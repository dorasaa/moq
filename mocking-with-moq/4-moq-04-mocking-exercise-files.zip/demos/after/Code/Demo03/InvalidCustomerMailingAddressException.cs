using System;

namespace PluralSight.Moq.Code.Demo03
{
    public class InvalidCustomerMailingAddressException : Exception
    {
    }
}