namespace PluralSight.Moq.Code.Demo03
{
    public interface ICustomerRepository
    {
        void Save(Customer customer);
    }
}