namespace PluralSight.Moq.Code.Demo03
{
    public class CustomerToCreateDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}