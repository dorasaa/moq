namespace PluralSight.Moq.Code.Demo03
{
    public class Address
    {
        public string Country { get; set; }
    }
}