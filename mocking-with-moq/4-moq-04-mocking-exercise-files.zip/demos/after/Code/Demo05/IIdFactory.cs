namespace PluralSight.Moq.Code.Demo05
{
    public interface IIdFactory
    {
        int Create();
    }
}