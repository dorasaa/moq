namespace PluralSight.Moq.Code.Demo05
{
    public interface ICustomerRepository
    {
        void Save(Customer customer);
    }
}