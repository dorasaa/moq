using System;

namespace PluralSight.Moq.Code.Demo04
{
    public class InvalidMailingAddressException : Exception
    {
    }
}