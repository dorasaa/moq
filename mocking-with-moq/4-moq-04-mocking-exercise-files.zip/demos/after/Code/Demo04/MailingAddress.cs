namespace PluralSight.Moq.Code.Demo04
{
    public class MailingAddress
    {
        public string Country { get; set; }
    }
}