namespace PluralSight.Moq.Code.Demo17
{
    public interface ICustomerRepository
    {
        void Save(Customer customer);
    }
}