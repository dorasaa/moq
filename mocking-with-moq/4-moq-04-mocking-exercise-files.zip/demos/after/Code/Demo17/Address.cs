namespace PluralSight.Moq.Code.Demo17
{
    public class Address
    {
    }
}