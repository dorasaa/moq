namespace PluralSight.Moq.Code.Demo17
{
    public class CustomerToCreateDto
    {
        public string Name { get; set; }
    }
}