namespace PluralSight.Moq.Code.Demo06
{
    public interface ICustomerFullNameBuilder
    {
        string From(string firstName, string lastName);
    }
}