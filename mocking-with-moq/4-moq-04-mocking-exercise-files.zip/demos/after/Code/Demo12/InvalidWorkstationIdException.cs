using System;

namespace PluralSight.Moq.Code.Demo12
{
    public class InvalidWorkstationIdException : Exception
    {
    }
}