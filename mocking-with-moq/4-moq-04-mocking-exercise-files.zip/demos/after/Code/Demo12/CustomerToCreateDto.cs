namespace PluralSight.Moq.Code.Demo12
{
    public class CustomerToCreateDto
    {
        public string Name { get; set; }
    }
}