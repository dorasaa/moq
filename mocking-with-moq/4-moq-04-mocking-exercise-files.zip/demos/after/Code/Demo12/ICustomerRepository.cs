namespace PluralSight.Moq.Code.Demo12
{
    public interface ICustomerRepository
    {
        void Save(Customer customer);
    }
}