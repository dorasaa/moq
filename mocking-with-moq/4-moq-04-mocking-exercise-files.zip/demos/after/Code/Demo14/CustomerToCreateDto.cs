namespace PluralSight.Moq.Code.Demo14
{
    public class CustomerToCreateDto
    {
        public string Name { get; set; }
    }
}