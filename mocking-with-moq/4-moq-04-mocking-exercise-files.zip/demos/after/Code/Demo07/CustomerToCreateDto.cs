namespace PluralSight.Moq.Code.Demo07
{
    public class CustomerToCreateDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public CustomerStatus DesiredStatus { get; set; }
    }
}