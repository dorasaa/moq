namespace PluralSight.Moq.Code.Demo07
{
    public enum CustomerStatus
    {
        Bronze,
        Gold,
        Platinum
    }
}