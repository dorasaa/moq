namespace PluralSight.Moq.Code.Demo11
{
    public interface IAuditingInformation
    {
        int? WorkstationId { get; set; }
    }
}