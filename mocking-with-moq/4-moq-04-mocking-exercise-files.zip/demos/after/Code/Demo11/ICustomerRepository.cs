namespace PluralSight.Moq.Code.Demo11
{
    public interface ICustomerRepository
    {
        void Save(Customer customer);
    }
}