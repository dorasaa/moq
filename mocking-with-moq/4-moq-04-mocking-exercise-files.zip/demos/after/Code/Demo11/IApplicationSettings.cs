namespace PluralSight.Moq.Code.Demo11
{
    public interface IApplicationSettings
    {
        ISystemConfiguration SystemConfiguration { get; set; }
    }
}