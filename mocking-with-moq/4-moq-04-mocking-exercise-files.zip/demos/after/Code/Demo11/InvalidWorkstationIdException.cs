using System;

namespace PluralSight.Moq.Code.Demo11
{
    public class InvalidWorkstationIdException : Exception
    {
    }
}