namespace PluralSight.Moq.Code.Demo11
{
    public class CustomerToCreateDto
    {
        public string Name { get; set; }
    }
}