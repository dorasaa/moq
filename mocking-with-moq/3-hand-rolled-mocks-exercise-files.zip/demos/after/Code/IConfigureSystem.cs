namespace PluralSight.HandRolledMocks.Code
{
    public interface IConfigureSystem
    {
        bool LogStackFor(LogLevel logLevel);
    }
}