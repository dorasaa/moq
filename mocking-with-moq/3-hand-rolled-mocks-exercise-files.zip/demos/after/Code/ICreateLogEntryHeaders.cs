namespace PluralSight.HandRolledMocks.Code
{
    public interface ICreateLogEntryHeaders
    {
        void For(LogLevel logLevel);
    }
}