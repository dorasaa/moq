namespace PluralSight.HandRolledMocks.Code
{
    public interface ICreateLogEntryFooter
    {
        void For(LogLevel logLevel);
    }
}