namespace PluralSight.HandRolledMocks.Code
{
    public enum LogLevel
    {
        Debug,
        Info,
        Error,
        Fatal
    }
}