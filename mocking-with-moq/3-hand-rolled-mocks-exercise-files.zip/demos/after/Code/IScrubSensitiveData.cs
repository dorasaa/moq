namespace PluralSight.HandRolledMocks.Code
{
    public interface IScrubSensitiveData
    {
        string From(string messageToScrub);
    }
}